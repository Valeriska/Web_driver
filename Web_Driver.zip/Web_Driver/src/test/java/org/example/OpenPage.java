package org.example;
package org.tests.pageFactory;

import org.openqa.selenium.WebDriver;

public class OpenPage {
    WebDriver driver;

    public OpenPage(WebDriver driver) {
        this.driver = driver;
    }

    public void open() {
        driver.get("https://www.i.ua/");
    }
}
