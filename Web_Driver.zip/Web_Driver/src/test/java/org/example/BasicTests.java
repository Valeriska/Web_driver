package org.example;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;

public class BasicTests {

    @BeforeClass
    public void precondition(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Valeriska\\chromedriver_win32 (1)\\chromedriver.exe");
    }

    @Test
public static void correctUsername (){
        WebDriver driver = new ChromeDriver();
        OpenPage openPage = PageFactory.initElements(driver, OpenPage.class);
        openPage.open();
        WebElement email = driver.findElement(By.name("login"));
        email.sendKeys("valeriya.zakharchenko");
        WebElement pass = driver.findElement(By.name("pass"));
        pass.sendKeys("5555zzzz");
        driver.findElement(By.cssSelector("body > div.Branding_body.page_medium > div.Body.clear > div.Left > div.Left > div.block_gamma_gradient.mail_login > div.content.clear > form > p > input[type=submit]")).click();


    }
    @Test
    public static void incorrectUsername (){
        WebDriver driver = new ChromeDriver();
        OpenPage openPage = PageFactory.initElements(driver, OpenPage.class);
        openPage.open();
        WebElement email = driver.findElement(By.name("login"));
        email.sendKeys("valeriya_zakharchenko");
        WebElement pass = driver.findElement(By.name("pass"));
        pass.sendKeys("5555zzzz");
        driver.findElement(By.cssSelector("body > div.Branding_body.page_medium > div.Body.clear > div.Left > div.Left > div.block_gamma_gradient.mail_login > div.content.clear > form > p > input[type=submit]")).click();


    }
    @Test
    public static void emptyUsername (){
        WebDriver driver = new ChromeDriver();
        OpenPage openPage = PageFactory.initElements(driver, OpenPage.class);
        openPage.open();
        WebElement email = driver.findElement(By.name("login"));
        email.sendKeys("");
        WebElement pass = driver.findElement(By.name("pass"));
        pass.sendKeys("");
        driver.findElement(By.cssSelector("body > div.Branding_body.page_medium > div.Body.clear > div.Left > div.Left > div.block_gamma_gradient.mail_login > div.content.clear > form > p > input[type=submit]")).click();


    }

}
